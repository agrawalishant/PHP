<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Chat_controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function userSendMsg()
    {
    	$senderid = $this->input->post('userid');
    	$reciverid = $this->input->post('astroid');
    	$msg = $this->input->post('message');
    	$offset = $this->input->post('offset');
    	
    	if($offset > 0){
    		$limit = $offset*20;
    	}else{
    		$limit = 20;	
    	}

    	$InsertData = [
						'reciver_id' => $reciverid,
						'sender_id' => $senderid,
						'message' => $msg,
						'status' => 1
					];
    	$res = addData('chat_messsage',$InsertData);
    	if($res)
    	{
    		//$req = fetchbyresultwhere('chat_messsage',array('reciver_id'=>$reciverid));
    		$where = '`sender_id`='.$reciverid.' AND `reciver_id`='.$senderid;
    		$req = fetchbyresultwherelimitorder('chat_messsage',array('reciver_id'=>$reciverid,'sender_id'=>$senderid),$where,$limit,'id','DESC');	
    		if($req)
    		{
    			$result = array('sucess'=>'true','msg'=>$req);
    		}
    		else
    		{
    			$result = array('sucess'=>'true','msg'=>'No Message Found');	
    		}
    	}
    	else
    	{
    		$result = array('sucess'=>'true','msg'=>'Message Not Send');	
    	}
    	echo json_encode($result);
    }

    public function ShowuserChat()
    {
    	$senderid = $this->input->post('userid');
    	$reciverid = $this->input->post('astroid');
    	$offset = $this->input->post('offset');
    	
    	if($offset > 0){
    		$limit = $offset*20;
    	}else{
    		$limit = 20;	
    	}

    	$astrologer = fetchbyresultwhere('astrologers',array('astro_id'=>$reciverid));
    	$chatamt = $astrologer[0]['astro_chat_rate'];
    	$chatamtdiscount = $astrologer[0]['astro_chat_rate_discount'];
    	$chatamt = 0;
    	$chatamtdiscount = 50;
    	if($chatamt>0 && $chatamt!=0)
    	{
    		if($chatamtdiscount>0)
    		{
    			$chatper = ($chatamt*$chatamtdiscount)/100;
    			$chatFinalamt = $chatamt-$chatper;
    		}
    		else
    		{
    			$chatFinalamt = $chatamt;
    		}
    	}
    	elseif ($chatamt==0) {
    		$chatFinalamt = $chatamt;
    	}

    	$wallet = fetchbyresultwhere('wallet',array('user_id'=>$senderid));
    	$userWalletAmt = $wallet[0]['wallet_amt'];
    	if(($userWalletAmt > 0)&&($userWalletAmt > $chatFinalamt))
    	{
	    	$where = '`sender_id`='.$reciverid.' AND `reciver_id`='.$senderid;
			$req = fetchbyresultwherelimitorder('chat_messsage',array('reciver_id'=>$reciverid,'sender_id'=>$senderid),$where,$limit,'id','DESC');
			//echo $this->db->last_query();exit;	
			if($req)
			{
				$result = array('sucess'=>'true','msg'=>$req);
			}
			else
			{
				$result = array('sucess'=>'true','msg'=>'No Message Found');	
			}
		}
		else{
			$result = array('success'=>'true','msg'=>'Insufficient Amount For Chat Please Reharge Your Wallet');
		}	
    	echo json_encode($result);
    }

}
?>    	