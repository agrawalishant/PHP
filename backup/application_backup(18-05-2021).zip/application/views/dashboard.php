<style>
    .card-01 {
     border:1px solid #fff;
     background-color:#fff;
     text-align:center;
     width:100%;
     height:100px;
    }
</style>


<div id="content-page" class="content-page">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
               <div class="card-01">
                  <h4>Total Students</h4>
                  <p><?php echo $stu; ?></p>
               </div>
           </div>
           <div class="col-md-4">
               <div class="card-01">
                  <h4>Total Instructors</h4>
                  <p><?php echo $inst; ?></p>
               </div>
           </div>
        </div>
    </div>
</div>
 

