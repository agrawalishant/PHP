    
  <div class="warpper clearfix">

        <!--Features app-->

        <section id="features-app" class="padd-80 head-section">

            <!--container-->

            <div class="container">
                <div class="row align-items">
 					<div class="col-md-6 col-sm-12"> 
 					<div class="covid-content-section">
					<h2>Our Approch to Covid-19</h2>
					<div class="sr-line"></div>
						<p>The safety and well-heing of everyane who uses Uber is at the hean of what we do. We're continuing to expand our response lo COVID-19 wilh new teatures for our users, support for those who eam on our platform, and partnerships and initiatives that serve our cities.
					</p>
				</div>
 				</div>
                    <div class="col-md-6 col-sm-12">
                      <img src="<?php echo base_url();?>assets/images/Mask Group 2.png" alt="" class="maskcovid-img"> 
                    </div>

                    <!-- content tab-->

                    <!-- content tab-->

                </div>
                 <div class="row padd-80 align-items">
				
				
				 <div class="col-md-6 col-sm-12">

                      <img src="<?php echo base_url();?>assets/images/Mask Group 3.png" alt="">
                    </div>


				<div class="col-md-6 col-sm-12"> 
					<div class="covid-img-2">
						<h2>No Mask,</br>No Class.</h2>
						<div class="sr-line"></div>
						<p>To help protect the health and safety of everyone, face coverings or masks are mandatory for anyone riding or driving with Uber (unless exempt). You can leam more about our face covering policy including the exceptions here.
					</div>
				</p>
 				</div>

            </div>
            <!--container-->

        </section>






 <section id="features-app" class="padd-80 icon-section">

            <!--container-->

            <div class="container">
			
			
			<h2>How  are we supporting Instructor & Students.</h2>
			<div class="sr-line"></div>
                <div class="row">
				 <div class="col-md-3 col-sm-3 col-12">
				 	<div class="covid-icon">
						<img src="<?php echo base_url();?>assets/images/car_front-filled.png" alt=""> 
						<h5>Well-maintained cars.</h5>
				 	</div>
				 </div>

<div class="col-md-3 col-sm-3 col-12">
	<div class="covid-icon">
				 <img src="<?php echo base_url();?>assets/images/masks-filled.png" alt=""> 
				 <h5>Taking measures to protect students.</h5>
				</div>
				 </div>
				 
				 <div class="col-md-3 col-sm-3 col-12">
				 	<div class="covid-icon">
				 <img src="<?php echo base_url();?>assets/images/person_group-filled.png" alt=""> 
				 <h5>Educating every Student.</h5>
				</div>
				 </div>
				 
				 <div class="col-md-3 col-sm-3 col-12">
				 	<div class="covid-icon">
				 <img src="<?php echo base_url();?>assets/images/stethoscope-filled.png" alt=""> 
				 <h5>We support NHS staff.</h5>
				</div>
				 </div>


                </div>

            </div>
            <!--container-->

        </section>


<section id="features-app" >

            <!--container-->

            <div class="container">
			
			
			
                <div class="row sp-ins-sec">
				
			 <div class="col-md-6 col-sm-12">
				<h2>Support The NHS</h2>
				<div class="sr-line"></div>
				<p>The safety and wellbeing of everyone who uses DV Driving is always our priority. We are committed to supporting public authorities and cities as they work to stem the COVID-19 pandemic. 

</p>
				 </div>
				 
				 <div class="col-md-6 col-sm-12">
				 <img src="<?php echo base_url();?>assets/images/Mask Group 1.png" alt=""> 
				
				 </div>


                </div>

            </div>
            <!--container-->

        </section>
      

        <!--contact-->
       

    </div>