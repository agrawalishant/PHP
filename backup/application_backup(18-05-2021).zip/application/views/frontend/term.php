    
  <div class="warpper clearfix">

        <!--Features app-->
<style>
    .pp-01 
    {
    background: #373737;
    text-align: center;
    color: #fff;
    padding: 5px;
    border: 4px solid #fdc405;
    }

.pp-01 h5 {
    margin-bottom: 0px;
}

.pp-section h5{
    color:#000;
}
.pp-section ul li {
    color:#000;
}
.pp-section ol{
    padding-left:30px;
}
.pp-section ol li {
    color:#000;
}
</style>

 <section id="features-app" class="padd-80 icon-section head-section">

            <!--container-->

            <div class="container">
			
			
			<h2>Terms & Conditions</h2>
			<div class="sr-line"></div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="pp-section">
                        <p><strong>Brand Franchise Agreement.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong><a href="http://www.dvdrive.co.uk/"><strong>http://www.dvdrive.co.uk/</strong></a><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;</strong></p>
<p><strong>This franchise agreement (the &ldquo;Agreement") is made </strong></p>
<p><strong>Between (The &ldquo;School")</strong></p>
<p><strong>DV Drive Ltd - Driving School </strong></p>
<p><strong>36 park field road, Feltham, TW13 7LG. </strong></p>
<p><strong>AND (The &ldquo;Instructor&rdquo;) signed up instructor with digital sign.</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>And will continue in force and from accordance with the terms of the Agreement. unless terminated by either party.</strong></p>
<p><strong>This Agreement is to grant the Instructor a non-exclusive non-transferable franchise from the School to carry on the business of a driving instructor using its know-how, School Names and Distinctive Marks. </strong></p>
<p><strong>This Agreement defines the full extent of the relationship, rights and obligations between both parties; no other relationship is created, nor should be inferred or implied. </strong></p>
<ol>
<li><strong> Commencement </strong></li>
</ol>
<p><strong>1.1. &nbsp;The provisions of this Agreement shall apply as from joining as instructor (the &ldquo;Commencement Date") and shall be for an initial period defined in Schedule 1 (the &ldquo;Initial Term") (unless terminated earlier in accordance with Clause 10). </strong></p>
<p><strong>1.2. &nbsp;Either party may terminate this agreement at the expiry of the Initial Term by giving written notice to the other party of their intention to do so, not less than four weeks. For the avoidance of doubt, such written notice should be given.</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>1.3. &nbsp;Should neither party terminate this agreement in accordance with Clauses 1.2 or then this agreement will automatically renew for successive minimum terms as defined in Schedule 1 (&ldquo;Subsequent Term"). Each Subsequent Term will automatically renew unless either party terminates this agreement by giving written notice to the other party no less than four weeks prior of that Subsequent Term. </strong></p>
<ol start="2">
<li><strong> Payments Due </strong></li>
</ol>
<p><strong>2.1. &nbsp;</strong><strong>10% commission of each pupil&rsquo;s payments </strong><strong>as defined in Schedule. </strong></p>
<p><strong>2.2. &nbsp;The Fee is fixed for the Initial Term. The School may alter the Fee in accordance with of the Agreement by giving the Instructor not less than 4 weeks written notice before the expiry of the Initial Term. </strong></p>
<ol start="3">
<li><strong> Vehicle </strong></li>
</ol>
<p><strong>3.1. &nbsp;The Instructor undertakes to provide a dual controlled tuition car (the &ldquo;Car&rdquo;), which shall be in any colour, manual or automatic transmission: </strong></p>
<p><strong>3.2. &nbsp;any other vehicle of a make and model decided by the School to be suitable for the purpose of teaching learners to drive. </strong></p>
<p><strong>3.3. &nbsp;The Car must not be more than 6 years old from the date of first registration. The School reserves the right to add and remove cars time to time if not suitable as per company policy. </strong></p>
<p><strong>3.4. &nbsp;The Instructor is responsible for: any purchase or finance costs of the Car or&nbsp;road tax and any other related to car. </strong></p>
<p><strong><u>frequently if requested by the School, proof that the Car is required; </u></strong></p>
<p><strong>3.5. &nbsp;maintaining fully comprehensive insurance on the Car including specific use for driving instruction, and shall provide to the School on an annual basis and more. </strong></p>
<p><strong>3.6.&nbsp;fitted of dual controls. </strong></p>
<p><strong>3.7. &nbsp;day-to-day maintenance (e.g., checking oil, water, tyres, screen wash) and where necessary purchasing oil, screen wash etc. </strong></p>
<p><strong>3.8. &nbsp;checking and ensuring that the Car complies with the legal requirements in relation to road traffic legislation.</strong></p>
<p><strong>3.9. cleanliness and general good condition of the Car including any decaling.</strong></p>
<p><strong>3.10. notifying the school promptly of any defect or damage.</strong></p>
<p><strong>3.11. &nbsp;The School is under no obligation under this agreement to provide the Instructor with a car at any time and will not be liable in any way to the Instructor or any third party for any losses or damages, claims or expenses, including loss of business, through the Instructor&rsquo;s failure to provide a suitable car. </strong></p>
<ol start="4">
<li><strong> Rights </strong></li>
</ol>
<p><strong>4.1. &nbsp;For the duration of this Agreement and subject to the Instructor obtaining the School's prior written permission, the School grants the non-exclusive, non-assignable and personal right to the Instructor to use the School's name and any distinctive marks or logos (the &ldquo;School's Name and Distinctive Marks") which include but are not limited to the School&rsquo;s business or trading names, logos, registered and unregistered trademarks, copyrighted material and design rights for purposes connected with the Instructor's business as a driving instructor and to promote the Instructor's business, including the right to publicise the Instructor's association with the School. </strong></p>
<p><strong>4.2. &nbsp;The Instructor agrees not to use the School's Name and Distinctive Marks in any way that the School considers detrimental to the business and reputation of the School, or in any way detract from the professional image or standing of the School. </strong></p>
<p><strong>4.3. &nbsp;The School reserves the right to enter into agreements with others, whether on identical, similar or other terms to those contained in this Agreement in the furtherance of its business. </strong></p>
<p><strong>4.4. &nbsp;The School reserves the right to amend or add to any clause in this Agreement at any time with four weeks&rsquo; written notice to the Instructor. </strong></p>
<p><strong>4.5. &nbsp;The School reserves the right to transfer, assign, novate or sub-contract all or any of its rights and obligations under this Agreement provided that the Instructors rights under this Agreement are not affected.</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong><u>The Instructor does not have the right to: </u></strong></p>
<p><strong>4.6. &nbsp;Use the name of the School as a pledge for any purpose (whether for credit or otherwise); </strong></p>
<p><strong>4.7.&nbsp;Assign this Agreement nor the benefit of it to any other party; </strong></p>
<p><strong>4.8. &nbsp;Pass his/her business off as being the School, bind the School to any legal agreement or obligation, or otherwise hold him/herself out as the School either explicitly or implicitly other than as a franchisee carrying out the business of a driving instructor; </strong></p>
<p><strong>4.9. &nbsp;Give to any person any guarantee or indemnity regarding any service offered, which the Instructor is or may be unable to keep. </strong></p>
<ol start="5">
<li><strong> Responsibilities </strong></li>
</ol>
<p><strong>&nbsp;<u>During the course of this Agreement the School agrees to provide: </u></strong></p>
<p><strong>5.1. &nbsp;Such guidance to the Instructor as may be reasonable to assist with the development and success of the Instructor's business.</strong></p>
<p><strong>5.2. &nbsp;Any paperwork or stationery which the School from time to time requires to be used.</strong></p>
<p><strong>5.3. &nbsp;Such advertising material for distribution by the Instructor, as the School sees fit. High quantity or specialised requests may be charged to the Instructor at a cost.</strong></p>
<p><strong>5.4. &nbsp;The first issue of any uniform the School may choose to introduce to be worn by the Instructor. </strong></p>
<p><strong><u>During the course of this Agreement the Instructor agrees to: </u></strong></p>
<p><strong>5.5. &nbsp;Attend a Business Development Workshop if required by company, at a location designated by the School, travel costs to be met by the Instructor; </strong></p>
<p><strong>5.6.&nbsp;Maintain a clean, tidy and professional appearance and manner, and to wear such uniform as the School may choose to introduce; </strong></p>
<p><strong>5.7. &nbsp;Provide and maintain a mobile phone with text and answer phone facilities in order for the School to pass on pupil details. Use of mobile phones by the Instructor must comply with Traffic Law; </strong></p>
<p><strong>5.8.&nbsp;Run his/her business in such a way as to complement the high standards expected of a professional driving instructor and the reputation of the School; </strong></p>
<p><strong>5.10. &nbsp;Assist the School in developing and enhancing the reputation of the School; </strong></p>
<p><strong>5.11.&nbsp;Comply with any policies the School may issue from time to time;</strong></p>
<p><strong>5.12. &nbsp;Use his/her best efforts to assist the School in developing the business to the mutual benefit of both parties to this Agreement;</strong></p>
<p><strong>5.13. &nbsp;Assist the School in any way it deems necessary to resolve any complaint made about the Instructor;</strong></p>
<p><strong>5.14. &nbsp;Ensure that all users of the Car adhere to a strict "no smoking" policy whilst in the Car;</strong></p>
<p><strong>5.15. &nbsp;Maintain the Car in a clean and presentable conditions;</strong></p>
<p><strong>5.16. &nbsp;Sign and abide by such professional code of conduct as the School from time to time may prescribe and subscribe to;</strong></p>
<p><strong>5.17. &nbsp;Not pass to any third party any enquiry for lessons nor to pass to any third-party referrals of pupils for lessons which the Instructor receives from the School. If the Instructor receives enquiries for lessons that the Instructor does not utilise for him or herself, he or she shall pass them back to the School;</strong></p>
<p><strong>5.18. &nbsp;Not pass to any third party any property belonging to the School;</strong></p>
<p><strong>5.19. &nbsp;Maintain a valid licence as a driving instructor to teach for money or reward, to supply the School with a copy of that licence on commencement of this Agreement, and to supply the School with copies of any renewals of that licence and undertaking Disclosure and Barring Service (&ldquo;DBS&rdquo;) (formerly Criminal Record Bureau &ndash; CRB.</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<ol start="6">
<li><strong> Confidentiality </strong></li>
</ol>
<p><strong>6.1. &nbsp;Unless otherwise required by law, the Instructor will not divulge any information to any third party regarding the School's operation, procedures, business affairs or dealings, names or details of customers, or any other confidential information regarding the School or any individual within it. </strong></p>
<p><strong>6.2. &nbsp;If the Instructor is required to divulge information by law, the Instructor will notify the School before such information is divulged other than where prior notification is specifically prohibited by law. </strong></p>
<p><strong>6.3. &nbsp;The Instructor will not make disparaging remarks or comments about the School. </strong></p>
<p><strong>6.4. &nbsp;Other than providing the Instructor's telephone number to pupils and prospective pupils the School undertakes not to divulge any confidential information about the Instructor or the Instructor's business, including address and private telephone number(s), unless otherwise required by law or at the Instructor's own written request. </strong></p>
<ol start="7">
<li><strong> Standards</strong></li>
</ol>
<p><strong>&nbsp;During the course of this Agreement, the Instructor agrees: </strong></p>
<p><strong>7.1. To give lessons lasting not less than one hour in length.</strong></p>
<p><strong>&nbsp;&nbsp;&nbsp;&nbsp; 7.2. To give tuition to no more than one pupil at a time. </strong></p>
<p><strong>7.3.&nbsp;To have no more than two pupils in the Car at any time.</strong></p>
<p><strong>7.4. &nbsp;All pupil enquiries, new and existing, must be responded to as soon as possible and in any event within 24 hours of the request. </strong></p>
<p><strong>7.5. &nbsp;To keep such proper and lawful records of his/her business as may be required of a self-employed person. </strong></p>
<p><strong>7.6. &nbsp;To endeavour to comply with such standards and customer relations as may be from time to time required by the School; and to co-operate with the School by accurately completing and maintaining any information required by the School in a manner prescribed by the School. </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>7.7. Not to do anything that would bring the reputation of either himself or herself or the School into disrepute or which may impact on his or her reputation or fitness to carry on the profession of a driving instructor. </strong></p>
<ol start="8">
<li><strong> Policy </strong></li>
</ol>
<p><strong>8.1. &nbsp;The School reserves the right to change any of its policies at any time in the interests of the School and/or the Instructor&rsquo;s business, or to comply with industry rules or regulations. </strong></p>
<p><strong>8.2. &nbsp;Any change affecting this Agreement will be notified to the Instructor in accordance with Clause 4.4. </strong></p>
<ol start="9">
<li><strong> your diary and pricing </strong></li>
</ol>
<p><strong>9.1. &nbsp;</strong><strong>You will be sent a reminder when you have been given a new pupil. You are required to accept </strong><strong>the pupil within 24 hours. Failure to accept the pupil will result in them being reallocated to another ADI and you will still be charged a &pound;25 fee. </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>9.2. </strong><strong>keep your diary up to date. This will avoid any double bookings or pupil rejections</strong><strong>. </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>9.3. &nbsp;</strong><strong>Your pupil cap is pre-set accordingly availability. There is no guarantee we can fulfil the cap</strong><strong>.</strong></p>
<p><strong>9.3. &nbsp;No active direct debit mandate has been put in place, means company may ask or deduct the remaining payment. </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>9.4. &nbsp;</strong><strong>We have set your hourly rate to the standard hourly rate in the postcode area. This can be </strong><strong>changed once you have logged on to DV Drive instructor login. </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>9.5. &nbsp;The fees in this Agreement will be subject to review from time to time and (subject to clause 2.2) will be notified to the Instructor four weeks before the revised fees take effect. </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<ol start="10">
<li><strong> Termination </strong></li>
</ol>
<p><strong>10.1. &nbsp;Either party may terminate this Agreement by giving not less than four weeks&rsquo; notice to the other party in writing. </strong></p>
<p><strong>10.2. This agreement has automatically renewed for Subsequent Term(s) in accordance with Clause 1.3, either party may terminate the Agreement at the expiry date of the Subsequent Term in question by giving not less than four weeks&rsquo; notice to the other party in writing. Such notice to be given no later than 4 weeks prior. </strong></p>
<p><strong>10.3. &nbsp;The School may terminate this Agreement without prior notice if the Instructor breaches any term of this Agreement; </strong></p>
<p><strong>10.3.1. &nbsp;Is convicted of any offence which in the opinion of the School makes the instructor unfit to carry on the business of a driving instructor, is guilty of any act which brings the School into disrepute or which in the reasonable opinion of the School is prejudicial to its interests.</strong></p>
<p><strong>10.3.2. &nbsp;Is guilty of any serious professional negligence.</strong></p>
<p><strong>10.3.3. &nbsp;Is removed from or not allowed to enter, the Driver and Vehicle Standards Agency. </strong></p>
<p><strong>(DVSA), Register of Approved Driving Instructors; </strong></p>
<p><strong>10.3.4. &nbsp;Fails a DVSA check test and is unable or unwilling to correct the stated. </strong></p>
<p><strong>deficiencies in accordance with the DVSA Regulations; </strong></p>
<p><strong>10.3.5. &nbsp;Fails to comply with the DVSA Regulations. </strong></p>
<p><strong>10.3.6. &nbsp;Fails to pay any sums due under this Agreement (whether or not the reason for non-payment is the incapacity through illness or accident of the Instructor).</strong></p>
<p><strong>10.3.7. &nbsp;As a consequence of the Instructor's negligence causes or contributes to death or serious injury whilst driving whether or not whilst engaged as a driving instructor at the time; and Is medically unfit to carry on the profession of a driving instructor based on a </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>doctor&rsquo;s report; and Is abusive, aggressive, demonstrates any form of antisocial behaviour or uses foul language, whether written or verbal, towards the School&rsquo;s staff, trainers, Customers, suppliers or any member of the public for any reason whatsoever. </strong></p>
<p><strong>10.3.8.&nbsp;On termination for any of the reasons in clause 10.3 above, all payments owed by the Instructor to the School remaining under the term of this Agreement will immediately fall due and an administration charge may apply to the Instructor&rsquo;s account.</strong></p>
<p><strong>10.3.9.&nbsp;Any debt existing on termination of this Agreement may be handed to an approved third party for recovery, with no further notice to the Instructor. </strong></p>
<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 10.3.10. &nbsp;Any monies paid directly to the Instructor in advance of lessons constitute an agreement between the Instructor and the pupil. The Instructor agrees to refund any unused monies to such pupils on demand. </strong></p>
<p><strong>10.3.11. &nbsp;Any unused monies pre-paid to the School or its agents on behalf of any pupil the Instructor has delivered lessons to remain the property of the payer/pupil and will be determined according to the rules of the pre-payment scheme. The Instructor has no entitlement to unused monies. </strong></p>
<p><strong>Immediately on termination of this Agreement, the Instructor shall: </strong></p>
<p><strong>10.3.12. &nbsp;Return any property of the School in good and clean condition, and return any stationery or advertising materials bearing the School's name at their own cost, cease to use the School's Name and Distinctive Marks and any literature, stationery or other materials which indicate or appear to indicate a link with the School. </strong></p>
<p><strong>10.3.13. &nbsp;Remove any decals on the Car associated with the School at their own cost. </strong></p>
<p><strong>10.3.14. &nbsp;Not pass himself or herself off as being in any way connected to the School. </strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<ol start="11">
<li><strong> Marketing &amp; Copyright </strong></li>
</ol>
<p><strong>11.1. &nbsp;The School retains all rights and copyright to the School's Name and Distinctive Marks. </strong></p>
<p><strong>11.2. &nbsp;Use of the School's Name and Distinctive Marks in any advertising or promotional material is prohibited without the express written permission of the School. </strong></p>
<ol start="12">
<li><strong> Legality </strong></li>
</ol>
<p><strong>12.1. &nbsp;Failure to exercise any right under this Agreement does not constitute a waiver of those rights. </strong></p>
<p><strong>12.2. &nbsp;If any term or provision of this Agreement becomes unenforceable due to a change in British or European law, the remainder of this Agreement shall continue in force as though that unenforceable provision was not in existence. </strong></p>
<p><strong>12.3. &nbsp;This Agreement shall be construed in accordance with the law of England and Wales. Any dispute arising under or in connection with this Agreement shall be subject to the exclusive jurisdiction of the English Courts. </strong></p>
<p><strong>&nbsp;</strong></p>
<ol start="13">
<li><strong> Signatures</strong></li>
</ol>
<p><strong><br /> 13.1. Digital Signing this document signifies full acceptance of all the above terms. </strong></p>
<p><strong>Signed by the Instructor: </strong></p>
<p><strong>Signature: Digital sign by (clicking box to agree comply the agreement) </strong></p>
<p><strong>Brand Franchise Agreement Schedule between DV Drive LTD and &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Instructor.</strong></p>                  
                        </div>
                    </div>
                </div>

            </div>
            <!--container-->

        </section>

      

        <!--contact-->
       

    </div>