<?php error_reporting(0);?>

<!doctype html>
<html lang="en">
<head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title> DV Driving School </title>
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?php echo site_url('assets/images/favicon.ico'); ?>" />
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="<?php echo site_url('assets/admin/css/bootstrap.min.css'); ?>">
      <!-- Typography CSS -->
      <link rel="stylesheet" href="<?php echo site_url('assets/admin/css/typography.css'); ?>">
      <!-- Style CSS -->
      <link rel="stylesheet" href="<?php echo site_url('assets/admin/css/style.css'); ?>">
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="<?php echo site_url('assets/admin/css/responsive.css'); ?>">
      <link rel="stylesheet" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css">
   </head>
   <body>
      <!-- loader Start -->
      
         <!-- <div id="loading">
         </div> -->
          <!-- Wrapper Start -->
      <div class="wrapper">
      <!-- Sidebar  -->
  <style>
    td {
       text-align: left!important;
       white-space: normal!important;
    }
  </style>