

<section id="features-app" class="padd-80 head-section">
    <div class="container">
        
        <div class="row"> 
            <div class="col-md-3"></div>
            <div class="col-md-6 co-sm-12"> 
                <h2>MY Account</h2>
                <div class="sr-line"></div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 co-sm-12">
                <div class="tab-content">
                    
                </div>
            </div>
        </div>
        <div class="col-md-3"></div>
    </div> 
</section>

