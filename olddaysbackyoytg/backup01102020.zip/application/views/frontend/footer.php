  <!-- Footer-->

    <footer class="footer ">
        <div class="container-page ">

            <div class="footer-warpper ">

                <div class="footer-top">
                    <!--container-->
                    <div class="container ">

                        <div class="footer-top  clearfix ">

                            <div class="footer-bottom-content clearfix ">

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
                                        <div class="content-footer">

                                            <h5>Our Products</h5>

                                            <ul class="list-menu ">
                                                <li>
                                                    <a href=" ">Career </a>
                                                </li>

                                                <li>
                                                    <a href=" ">Hotels</a>
                                                </li>

                                                <li>
                                                    <a href=" ">Cares</a>
                                                </li>

                                                <li>
                                                    <a href=" ">Packages</a>
                                                </li>
                                                <li>
                                                    <a href=" ">Features</a>
                                                </li>

                                                <li>
                                                    <a href=" ">priceline<sup>TH</sup></a>
                                                </li>

                                            </ul>

                                        </div>

                                    </div>

                                    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
                                        <div class="content-footer">

                                            <div class="logo-footer ">
                                                <img src="<?php echo base_url();?>assets/images/logo.png" alt="">

                                            </div>
                                            <div class="text-footer ">
                                               <ul class="list-menu ">
                                                <li>
                                                    <a href=" ">Our Story </a>
                                                </li>

                                                <li>
                                                    <a href=" ">Investor Relations</a>
                                                </li>

                                                <li>
                                                    <a href=" ">Press Center</a>
                                                </li>

                                                <li>
                                                    <a href=" ">Advertise</a>
                                                </li>
                                                
                                            </ul>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
                                        <div class="content-footer">

                                            <h5>Resources</h5>

                                            <ul class="list-menu ">
                                                <li>
                                                    <a href=" ">Download </a>
                                                </li>

                                                <li>
                                                    <a href=" ">Helpcenter</a>
                                                </li>

                                                <li>
                                                    <a href=" ">Guides</a>
                                                </li>

                                                <li>
                                                    <a href=" ">Partner Network</a>
                                                </li>
                                                <li>
                                                    <a href=" ">Developers</a>
                                                </li>

                                                <li>
                                                    <a href=" ">Mechanics</a>
                                                </li>
                                                 <li>
                                                    <a href=" ">Cruises</a>
                                                </li>

                                            </ul>

                                        </div>

                                    </div>

                                    <div class="col-lg-2 col-md-4 col-sm-6 col-xs-12">
                                        <div class="content-footer">

                                            <h5>Extras</h5>

                                            <ul class="list-menu ">
                                                <li>
                                                    <a href=" ">Rental Deal </a>
                                                </li>

                                                <li>
                                                    <a href=" ">Repair Shop</a>
                                                </li>

                                                <li>
                                                    <a href=" ">View Booking</a>
                                                </li>

                                                <li>
                                                    <a href=" ">Hire Companies</a>
                                                </li>
                                                <li>
                                                    <a href=" ">New offers</a>
                                                </li>

                                            </ul>

                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">

                                        <div class="newsletter-block ">

                                           <!--  <img src="assets/images/icons/email-1.svg" alt=""> -->

                                            <h5>Subscribe to Newsletter</h5>

                                            <!-- Newsletter -->

                                            <div class="subscribe-form ">

                                                <form action="#" method="post" class="subscribe-mail">
                                                    <div class="form-group ft-form">
                                                        <input type="email" class="form-control email-input" placeholder="Enter your email">
                                                        <i class="fa fa-chevron-right" aria-hidden="true"></i>
                                                    </div>
                                                    <section class="ft-rating">
                                                       <h3>4.7</h3>
                                                       <p>rating 15644 Clients</p>
                                                       <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
    <section>
        <img src="<?php echo base_url();?>assets/images/rating-01.png" style="width: 80%">
    </section>
                                                   </section>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- Newsletter -->

                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                    <!--container-->
                </div>

            </div>
        </div>
<script src="https://momentjs.com/downloads/moment-with-locales.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    </footer>

    <!--Footer -->
    <!-- jQuery -->
    <!-- <script src="assets/js/jquery-3.3.1.min.js"></script> -->
    
</body>
</html>