<?php //include 'header.php'; ?>   



        <!--Begin Hero Section-->



        <section id="home">



            <div class="container-page">



                <!--container-->



                <div class="container">



                    <div class="row n-hight">



                        <div class="col-md-5 col-xs-5 col-sm-5 col-12">



                            <!--text-->



                            <div class="hero-text">



                                <h3>Looking to learn driving at your Convenient time?</h3>

                                <div class="sr-line"></div>

                                <h6> Discover the DV driving lessons at your convenient time. Our professional

instructors will come to your door step to teach driving.</h6>





                              



                            </div>



                            <!--text-->



                        </div>

                        <div class="col-md-7 col-xs-7 col-sm-7 col-12">



                            <!-- slider image -->



                         



                                <img src="<?php echo base_url();?>assets/images/slider-img-01.png" class="pd-tp-140" alt="">

                            <!-- slider image -->



                        </div>

                    </div>

				<form class="form-inline n-form" action="/action_page.php">

                       

                       <div class="form-group ">

                   <img src="<?php echo base_url();?>assets/images/location-map.png" class="form-width fm-icon" alt="">    



     <input type="text" placeholder="Postcode" class="form-control bd0">

 



</div>



<div class="form-group ">

<!--<img src="<?php //echo base_url();?>assets/images/location.png" class="form-width" alt="">       -->

 <i class="fa fa-car fm-icon" aria-hidden="true"></i>

 <select name="cars" id="cars" class="form-control bd0">

  <option value="volvo">Vehicle Type</option>

  <option value="Manual">Manual</option>

  <option value="Automated">Automated</option>

  

</select>

</div>



<div class="form-group ">

<!--<img src="<?php //echo base_url();?>assets/images/location.png" class="form-width" alt="">  -->

<i class="fa fa-calendar-check-o fm-icon" aria-hidden="true"></i>

<input type="date" id="birthday" class="form-control bd0" name="birthday">

<!-- <select name="cars" id="cars" class="form-control bd0">-->

<!--  <option value="volvo">Date / Time</option>-->

<!--  <option value="saab">Saab</option>-->

<!--  <option value="opel">Opel</option>-->

<!--  <option value="audi">Audi</option>-->

<!--</select>-->

</div>

    

  <a href="instructor-details.php" class="btn btn-blue">Search</a>

</form>



                </div>



                <!--container-->

            </div>



        </section>



        <!-- about block colored-->



       





        <!--About app-->



      



        <!--Features -->



        <section id="features" class="service-icon-sec">



            <div class="">



                <!--container-->

                <div class="container">



                    <div class="row">



                        <div class="row-centered">

                            <div class="col-centered col-lg-12">



                                <!--text-->

                                <p>How it Works</p>

                                <h2 class="title-h2">DV Drive With 3 following steps</h2>



                               <!--  <p class="font-p mg-tp-30 mg-bt-30">

                                    Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae

                                </p> -->

                                <!--text-->

                                

                                <!--  <img src="<?php //echo base_url();?>assets/images/Component 2.png" alt=""> -->

                            </div>



                        </div>



                        

                    </div>

                    <!-- <div class="sr-border-img">

                                    <img src="<?php echo base_url();?>assets/images/service-border.png">

                        </div>

                        <div class="sr-border-img">

                                    <img src="<?php echo base_url();?>assets/images/service-border.png" style="margin-left: 380px;">

                                </div> -->

                     <!-- service block-->

                    <div class="row service-section">

                        <div class="col-lg-4 col-md-4">

                            <div class="service-block">

                                <i class="fa fa-map-marker sr-icon" aria-hidden="true"></i>

                            </div>

                            <div class="service-block">

                            

                                <h3>Choose Location</h3>

                                <p>select your convenient location for your lesson.

                                </p>

                            </div>



                        </div>



                        <!-- service block-->



                        <!-- service block-->



                        <div class="col-lg-4 col-md-4">

                            <div class="service-block">

                                <i class="fa fa-briefcase sr-icon" aria-hidden="true"></i>

                            </div>

                            <div class="service-block">

                                

                                <h3>Choose Date / Time</h3>

                                <p>

                                    choose your date and time , DV will assign available instructor

                                </p>



                            </div>



                        </div>



                        <!-- service block-->



                        <!-- service block-->

                        <div class="col-lg-4 col-md-4">

                            <div class="service-block">

                              <i class="fa fa-calendar-check-o sr-icon" aria-hidden="true"></i>

                            </div>

                            <div class="service-block">



                                <h3>Start Learning </h3>

                                <p>With DV professional instructors, Start your driving  with ease 

                                </p>



                            </div>



                        </div>

                    </div>

                </div>



                <!--container-->



            </div>

        </section>



        <!--Features -->



        <!--Features app-->



        <section id="features-app" class="padd-80">



            <!--container-->



            <div class="container">

                <div class="row">





                    <div class="col-md-6 col-sm-12">



                      <img src="<?php echo base_url();?>assets/images/side-img.png" alt="">



                    </div>





                    <div class="col-md-6 col-sm-12">

                        <div class="service-heading">

                            <p>Our Services</p>

                            <h3>Feel the best experience with Our deals</h3>

                        </div>

                        <div class="sr-line" ></div>



                        <!-- tabs-->



                        <ul class="setps-content">



                            <li data-slide="1" class="setps-content-inner step1 active">

                                <div class="step-content-number ">

                                    <i class="fa fa-tags" aria-hidden="true"></i>

                                </div>

                                <div class="step-content-text">

                                    <h3>Deal for every budget</h3>

                                    <p>Incredible prices on hotels , flights , cars , and packages worldwide.</p>

                                </div>



                            </li>



                            <li data-slide="2" class="setps-content-inner step2">

                                <div class="step-content-number">

                                   <i class="fa fa-shopping-bag" aria-hidden="true"></i>

                                </div>

                                <div class="step-content-text">

                                    <h3>Best price guaranteed</h3>

                                    <p>Find a lower price? we'll refund you 100% of the difference.</p>

                                </div>



                            </li>



                            <li data-slide="3" class="setps-content-inner step3">

                                <div class="step-content-number">

                                   <i class="fa fa-cogs" aria-hidden="true"></i>

                                </div>

                                <div class="step-content-text">

                                    <h3>support 24/7</h3>

                                    <p>Find a lower price? we'll refund you 100% of the difference.

                                    </p>

                                </div>



                            </li>



                        </ul>



                        <!-- tabs-->



                    </div>



                    <!-- content tab-->



                    <!-- content tab-->



                </div>



            </div>

            <!--container-->



        </section>



        <!--Features app -->



        



        <!-- pricing table -->

	<section id="pricing" class="padd-80 ">



            <div class="container-pagee">

                <!--container-->



                <div class="container">



                    <div class="row">



                        <div class="col-lg-12 col-md-12">



                            <!-- text -->



                            <div class="text-center">

                                <p>Car type and Drivers</p>

                                <h2 class="title-h2">Explore our top instructors Performance</h2>

                                <div class="testi-tab">

                                <ul class="nav nav-tabs">

                                   <li onclick="function()">

                                       <a class="active" data-toggle="tab" href="#auto-tab">AUTO</a></li>

    <li onclick="function()" class="tb-2"><a data-toggle="tab" href="#mannual-tab">MANNUAL</a></li>

                                </ul>

                                </div>

                            <div class="tab-content">

                                <div id="auto-tab" class="tab-pane fade in show active">

                                    <section class="testimonials">

    <div class="container">



      <div class="row">

        <div class="col-sm-12">

          <div id="clinet-testi" class="clinet-testi owl-carousel">



            <!--TESTIMONIAL 1 -->

            <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 1 -->

            <!--TESTIMONIAL 2 -->

            <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 2 -->

            <!--TESTIMONIAL 3 -->

            <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 3 -->

            <!--TESTIMONIAL 4 -->

            <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 4 -->

            <!--TESTIMONIAL 5 -->

           <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price instbtn">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 5 -->

          </div>

        </div>

      </div>

      </div>

    </section>

                                </div>

                                <div id="mannual-tab" class="tab-pane fade">

                                    <section class="testimonials">

    <div class="container">



      <div class="row">

        <div class="col-sm-12">

          <div id="clinet-testi" class="clinet-testi owl-carousel">



            <!--TESTIMONIAL 1 -->

            <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 1 -->

            <!--TESTIMONIAL 2 -->

            <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 2 -->

            <!--TESTIMONIAL 3 -->

            <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 3 -->

            <!--TESTIMONIAL 4 -->

            <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 4 -->

            <!--TESTIMONIAL 5 -->

           <div class="item">

              <div class="shadow-effect table-plan">

                <img src="assets/images/test-img-01.png">

                <div class="price instbtn">

                    <button>Honda Civic</button>

                </div>

                    <h3>Sania Sopi</h3>

                    <p><span>$ 35</span><sub> /per hr</sub></p>

                    <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>

                    <div class="price-content-btn ">

                        <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>

                    </div>

              </div>

            </div>

            <!--END OF TESTIMONIAL 5 -->

          </div>

        </div>

      </div>

      </div>

    </section>

                                </div>

                            </div>

    <!-- END OF TESTIMONIALS -->

    

           



        <!-- testimonials end-->

                            </div>

                            

                            



                            <!-- text -->



                            <!-- table -->



                            <!-- table -->



                        </div>



                    </div>

                </div>

                <!--container-->



            </div>



        </section>



        



        <!-- pricing table -->



        <!-- testimonials start -->

           

    <!-- END OF TESTIMONIALS -->

    

           



        <!-- testimonials end-->

        <!--contact-->



    </div>



    <!-- Footer-->



   <?php //include 'footer.php'; ?>



    <!--Footer -->

    <!-- jQuery -->

    <!-- <script src="<?php //echo base_url();?>assets/js/jquery-3.3.1.min.js"></script> -->

    

</body>

</html>