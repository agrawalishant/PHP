  <?php include 'header.php'; ?>
  <div class="warpper clearfix">
    
        <section id="home">

            <div class="container-page">

                <!--container-->

                <div class="container">

                    <div class="row n-hight">

                        <div class="col-md-5 col-xs-5 col-sm-5 col-12">

                            <!--text-->

                            <div class="hero-text">

                                <h3>Looking to learn driving at your Convenient time?</h3>
                                <div class="sr-line"></div>
                                <h6> Discover the DV driving lessons at your convenient time. Our professional
instructors will come to your door step to teach driving.</h6>


                              

                            </div>

                            <!--text-->

                        </div>
                        <div class="col-md-7 col-xs-7 col-sm-7 col-12">

                            <!-- slider image -->

                         

                                <img src="assets/images/slider-img-01.png" class="pd-tp-140" alt="">
                            <!-- slider image -->

                        </div>
                    </div>
				<form class="form-inline n-form" action="/action_page.php">
                       
                       <div class="form-group ">
                   <img src="assets/images/location-map.png" class="form-width fm-icon" alt="">    
<input type="text" placeholder="Postcode" class="form-control bd0">
</div>

<div class="form-group ">
<!--<img src="assets/images/location.png" class="form-width" alt="">       -->
 <i class="fa fa-car fm-icon" aria-hidden="true"></i>
 <select name="cars" id="cars" class="form-control bd0">
  <option value="volvo">Vehicle Type</option>
  <option value="Manual">Manual</option>
  <option value="Automated">Automated</option>
</select>
</div>

<div class="form-group ">
<!--<img src="assets/images/location.png" class="form-width" alt="">  -->
<i class="fa fa-calendar-check-o fm-icon" aria-hidden="true"></i>
<input type="date" id="birthday" class="form-control bd0" name="birthday">
<!-- <select name="cars" id="cars" class="form-control bd0">-->
<!--  <option value="volvo">Date / Time</option>-->
<!--  <option value="saab">Saab</option>-->
<!--  <option value="opel">Opel</option>-->
<!--  <option value="audi">Audi</option>-->
<!--</select>-->
</div>
    
  <a href="book-instructor.php" class="btn btn-blue">Search</a>
</form>

                </div>

                <!--container-->
            </div>

        </section>
        <!--Features app-->

        <section id="features-app" class="inst-section">
        
            <!--container-->
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-xs-12">
                        <h3 class="title-h2">OUR INSTRUCTOR</h3>
                    </div>
                </div>
                <div class="sr-line inst"></div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="item instbtn">
                            <div class="shadow-effect table-plan">
                                <img src="assets/images/test-img-01.png">
                                <div class="price">
                                    <button>Honda Civic</button>
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                                <h3>Sania Sopi</h3>
                                <p><span>$ 35</span><sub> /per hr</sub></p>
                                <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>
                                <div class="price-content-btn ">
                                    <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>
                                </div>
                                   
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="item instbtn">
                            <div class="shadow-effect table-plan">
                                <img src="assets/images/test-img-01.png">
                                <div class="price">
                                    <button>Honda Civic</button>
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                                <h3>Sania Sopi</h3>
                                <p><span>$ 35</span><sub> /per hr</sub></p>
                                <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>
                                <div class="price-content-btn ">
                                    <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="item instbtn">
                            <div class="shadow-effect table-plan">
                                <img src="assets/images/test-img-01.png">
                                <div class="price">
                                    <button>Honda Civic</button>
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                </div>
                                <h3>Sania Sopi</h3>
                                <p><span>$ 35</span><sub> /per hr</sub></p>
                                <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>
                                <div class="price-content-btn ">
                                    <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>
                                </div>
                            </div>
                        </div>
                    </div>
                        
                </div>
                <div class="row padd-80">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="item instbtn">
                            <div class="shadow-effect table-plan">
                                <img src="assets/images/test-img-01.png">
                                <div class="price">
                                    <button>Honda Civic</button>
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                </div>
                                <h3>Sania Sopi</h3>
                                <p><span>$ 35</span><sub> /per hr</sub></p>
                                <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>
                                <div class="price-content-btn ">
                                    <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="item instbtn">
                            <div class="shadow-effect table-plan">
                                <img src="assets/images/test-img-01.png">
                                <div class="price">
                                    <button>Honda Civic</button>
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                                <h3>Sania Sopi</h3>
                                <p><span>$ 35</span><sub> /per hr</sub></p>
                                <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>
                                <div class="price-content-btn ">
                                    <a href="book-instructor.php" class="btn btn-green ">Book A Class</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="item instbtn">
                            <div class="shadow-effect table-plan">
                                <img src="assets/images/test-img-01.png">
                                <div class="price">
                                    <button>Honda Civic</button>
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span> 
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                </div>
                                <h3>Sania Sopi</h3>
                                <p><span>$ 35</span><sub> /per hr</sub></p>
                                <p class="test-border">Auto Car Instructor ! <span>4.8 rating </span> ! Highly Recommended</p>
                                <div class="price-content-btn ">
                                    <a href=" " class="btn btn-green ">Book A Class</a>
                                </div>
                            </div>
                        </div>
                    </div>
                        
                </div>
   
            <!--container-->
            </div>
        </section>






 


      

        <!--contact-->
        <?php include 'footer.php'; ?>

    </div>